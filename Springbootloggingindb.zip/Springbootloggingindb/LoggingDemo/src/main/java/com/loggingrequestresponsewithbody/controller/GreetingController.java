package com.loggingrequestresponsewithbody.controller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import com.loggingrequestresponsewithbody.model.GreetingRequest;
import com.loggingrequestresponsewithbody.model.GreetingResponse;
import com.loggingrequestresponsewithbody.service.LoggingServiceImpl;

import java.util.concurrent.atomic.AtomicLong;

@RestController
public class GreetingController {
	private static final Logger log = LoggerFactory.getLogger(GreetingController.class);
	
    private final AtomicLong count = new AtomicLong();

    @GetMapping("greetings/{id}")
    public GreetingResponse getGreeting(@PathVariable("id") Long id) {
    	log.info("getGreeting method called");
    	return null;
        //return GreetingResponse.builder().id(id).message("Hello world!").build();
    }

    @PostMapping("greetings")
    public GreetingResponse createGreeting(@RequestBody GreetingRequest greetingRequest) {
    	log.info("createGreeting method called");
       // return GreetingResponse.builder().id(count.incrementAndGet()).message(greetingRequest.getMessage()).build();
    	return null;
    }
}
